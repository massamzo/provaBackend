package databasePack;

import java.sql.Connection;

public class DatabaseHome extends Database{
	private Connection conn = null;
	private QueryManager qm;
	
	

}
